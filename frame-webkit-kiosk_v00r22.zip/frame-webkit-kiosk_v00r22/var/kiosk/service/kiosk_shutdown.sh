#!/usr/bin/env bash

snap set ubuntu-frame daemon=false
