############################################################################################
#                                                                                          #
# install_frame_webkit_kiosk.sh: Script para instalar frame-webkit-kiosk                   #
#                                                                                          #
#------------------------------------------------------------------------------------------#
#                                                                                          #
# Script para instalar quioscos Webkit mediante ubuntu-frame en Ubuntu Server              # 
#                                                                                          #
#  - WebKit port optimized for embedded devices (https://wpewebkit.org/)                   #
#  - wpe-webkit-mir-kiosk snap (https://gitlab.com/glancr/wpe-webkit-snap)                 #
#  - Ubuntu Server: https://ubuntu.com/download/server                                     #
#                                                                                          #
#                                                                                          #
#------------------------------------------------------------------------------------------#
#                                                                                          #
# Autor         : Felipe Muñoz Brieva - digitaliza.aapp@gmail.com                          #
#                                                                                          #
#------------------------------------------------------------------------------------------#
#                                                                                          #
# Modificaciones:                                                                          #
#                                                                                          #
# 20/05/2022      Versión inicial                                                          #
#   Felipe                                                                                 #
#                                                                                          #
############################################################################################

KIOSK_VERSION="00.22"
VAR_KIOSK="/var/kiosk"

SCRIPT_BOOT=$VAR_KIOSK"/service/kiosk_boot.sh"
SCRIPT_SHUTDOWN=$VAR_KIOSK"/service/kiosk_shutdown.sh"

SERVICENAME_BOOT=kiosk_boot
SERVICENAME_SHUTDOWN=kiosk_shutdown

RC_LOCAL="/etc/rc.local"
LSB_KIOSK="/etc/lsb-release-frame-webkit-kiosk"
CERTIFICADOS="/Certificados"

# Actualizar sistema e instalar sistema grafico
apt update
apt upgrade -y

apt install openbox xinit xterm x11-xserver-utils yad mlocate plymouth-themes -y

# Copiar scripts para el quiosco
cp -ax .$VAR_KIOSK /var/.

# Crear carpeta para cargar certificados *.crt
mkdir $CERTIFICADOS 
chmod 777 $CERTIFICADOS 

# Version frame-webkit-kiosk 
cat > $LSB_KIOSK <<EOF
KIOSK_ID=frame-webkit-kiosk
KIOSK_RELEASE=$KIOSK_VERSION
KIOSK_DESCRIPTION="Quiosco generico: ubuntu-frame con wpe-webkit-mir-kiosk"
EOF


# Ajustar inicio del sistema (/etc/rc.local)
cat > $RC_LOCAL <<EOF
#!/bin/bash

. /var/kiosk/kiosk_config

. \$FILE_KIOSK_LIB

snap set ubuntu-frame daemon=false

dhclient -r
dhclient

version_ubuntu_frame=$(snap list | grep ubuntu-frame | awk '{print $2}')

if [ -z $version_ubuntu_frame ]; then
   \var\kiosk\install\install_snap_frame_webkit_kiosk.sh
   exit 0
fi

if grep -q "\$MODE_MENU" "\$CMDLINE"; then

   kiosk_menu

 elif grep -q "\$MODE_INSTALL" "\$CMDLINE"; then

   kiosk_install

 elif grep -q "\$MODE_CHG_URL" "\$CMDLINE"; then

   kiosk_chg_url

 elif grep -q "\$MODE_ADD_CRT" "\$CMDLINE"; then

   kiosk_add_crt

 elif grep -q "\$MODE_ADMIN" "\$CMDLINE"; then

   kiosk_admin

 else

   kiosk_menu

fi

exit 0
EOF

chmod +x $RC_LOCAL 

# Instalar servicios de arranque (kiosk_boot) y apagado (kiosk_shutdown)

# kiosk_boot: Servicio de arranque

cat > $SCRIPT_BOOT <<EOF
#!/usr/bin/env bash

echo -n quiet >/sys/module/apparmor/parameters/audit

truncate -s 0 /var/log/syslog
truncate -s 0 /var/log/kern.log
EOF

echo "1-------------------------------------"

chmod +x $SCRIPT_BOOT

echo "2-------------------------------------"

cat > /etc/systemd/system/$SERVICENAME_BOOT.service <<EOF
[Service]
ExecStart=$SCRIPT_BOOT
[Install]
WantedBy=default.target
EOF

# kiosk_shutdown: Servicio de apagado 

cat > $SCRIPT_SHUTDOWN <<EOF
#!/usr/bin/env bash

snap set ubuntu-frame daemon=false
EOF
echo "3-------------------------------------"

chmod +x $SCRIPT_SHUTDOWN

echo "4-------------------------------------"

cat > /etc/systemd/system/$SERVICENAME_SHUTDOWN.service <<EOF
[Unit]
Description=Kiosk shutdown script
DefaultDependencies=no
Conflicts=reboot.target
Before=poweroff.target halt.target shutdown.target reboot.target
Requires=poweroff.target

[Service]
Type=oneshot
ExecStart=$SCRIPT_SHUTDOWN
TimeoutStartSec=0
RemainAfterExit=yes

[Install]
WantedBy=halt.target reboot.target shutdown.target
EOF

echo "5-------------------------------------"

echo "Instalación finalizada"

exit 0
