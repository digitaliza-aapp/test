#!/usr/bin/env bash

SERVICENAME_BOOT=kiosk_boot
SERVICENAME_SHUTDOWN=kiosk_shutdown

# Instalar wpe-webkit-mir-kiosk en ubuntu-frame
snap install ubuntu-frame
snap install wpe-webkit-mir-kiosk
snap set ubuntu-frame daemon=true
snap connect wpe-webkit-mir-kiosk:wayland
snap set ubuntu-frame daemon=false

systemctl enable $SERVICENAME_BOOT
systemctl enable $SERVICENAME_SHUTDOWN

