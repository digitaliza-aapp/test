#!/usr/bin/env bash

echo -n quiet >/sys/module/apparmor/parameters/audit

truncate -s 0 /var/log/syslog
truncate -s 0 /var/log/kern.log

# Cambiar shell de dash a bash
echo "dash dash/sh boolean false" | debconf-set-selections
dpkg-reconfigure -p critical dash

