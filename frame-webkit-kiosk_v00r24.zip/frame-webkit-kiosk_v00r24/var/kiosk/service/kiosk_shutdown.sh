#!/usr/bin/env bash

. /var/kiosk/kiosk_config

. $FILE_KIOSK_LIB

set_kiosk_installed

snap set ubuntu-frame daemon=false
